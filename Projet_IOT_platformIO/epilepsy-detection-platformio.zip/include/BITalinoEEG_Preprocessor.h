/**
 * @file BITalinoEEG_Preprocessor.h
 * @brief Prétraitement des signaux EEG BITalino pour détection de crises épileptiques
 * 
 * Ce module gère:
 * - Conversion ADC vers microvolts (BITalino 10-bit ADC)
 * - Filtrage passe-bande (0.5-40 Hz) 
 * - Extraction de features temporelles et fréquentielles
 * - Normalisation selon le scaler d'entraînement
 */

#ifndef BITALINO_EEG_PREPROCESSOR_H
#define BITALINO_EEG_PREPROCESSOR_H

#include <Arduino.h>
#include <cmath>

// ============================================================================
// CONFIGURATION DU CAPTEUR BITALINO
// ============================================================================

// Résolution ADC BITalino (10-bit)
#define BITALINO_ADC_RESOLUTION 1024
#define BITALINO_VCC 3.3f  // Volts

// Paramètres de conversion EEG
// BITalino EEG: Gain = 1000, Vref = 3.3V
#define EEG_GAIN 1000.0f
#define EEG_VCC_HALF (BITALINO_VCC / 2.0f)

// ============================================================================
// CONFIGURATION DU TRAITEMENT DE SIGNAL
// ============================================================================

// Fréquence d'échantillonnage (doit correspondre au dataset d'entraînement)
#define SAMPLE_RATE 178  // Hz
#define SAMPLE_PERIOD_MS (1000.0f / SAMPLE_RATE)

// Taille de la fenêtre glissante (1 seconde)
#define WINDOW_SIZE 178
#define OVERLAP_PERCENTAGE 50
#define OVERLAP_SIZE (WINDOW_SIZE * OVERLAP_PERCENTAGE / 100)
#define STEP_SIZE (WINDOW_SIZE - OVERLAP_SIZE)

// Nombre de features extraites (doit correspondre au modèle)
#define NUM_FEATURES 194

// ============================================================================
// FILTRES PASSE-BANDE (Butterworth 4ème ordre)
// ============================================================================

// Filtre passe-haut (0.5 Hz) pour retirer la dérive DC
typedef struct {
    float a[5];  // Coefficients dénominateur
    float b[5];  // Coefficients numérateur
    float x[5];  // Buffer d'entrée
    float y[5];  // Buffer de sortie
} HighPassFilter;

// Filtre passe-bas (40 Hz) pour retirer les hautes fréquences
typedef struct {
    float a[5];
    float b[5];
    float x[5];
    float y[5];
} LowPassFilter;

// ============================================================================
// BUFFER DE DONNÉES EEG
// ============================================================================

typedef struct {
    float raw_buffer[WINDOW_SIZE];          // Signal brut
    float filtered_buffer[WINDOW_SIZE];     // Signal filtré
    float features[NUM_FEATURES];           // Features extraites
    int buffer_index;                       // Index circulaire
    bool window_ready;                      // Fenêtre complète?
} EEGBuffer;

// ============================================================================
// CLASSE PRINCIPALE DE PRÉTRAITEMENT
// ============================================================================

class BITalinoEEGPreprocessor {
public:
    /**
     * @brief Constructeur
     */
    BITalinoEEGPreprocessor();
    
    /**
     * @brief Initialisation des filtres et buffers
     */
    void begin();
    
    /**
     * @brief Convertir la valeur ADC BITalino en microvolts
     * @param adc_value Valeur ADC (0-1023)
     * @return Voltage en microvolts
     */
    float convertADCtoMicrovolts(int adc_value);
    
    /**
     * @brief Ajouter un échantillon EEG au buffer
     * @param adc_value Valeur brute ADC du BITalino
     * @return true si une nouvelle fenêtre est prête pour l'inférence
     */
    bool addSample(int adc_value);
    
    /**
     * @brief Extraire toutes les features de la fenêtre courante
     * @return Pointeur vers le tableau de features
     */
    float* extractFeatures();
    
    /**
     * @brief Obtenir les features normalisées (prêtes pour le modèle)
     * @return Pointeur vers les features normalisées
     */
    float* getNormalizedFeatures();
    
    /**
     * @brief Réinitialiser tous les buffers
     */
    void reset();
    
    /**
     * @brief Obtenir le signal filtré actuel
     */
    float* getFilteredSignal() { return eeg_buffer.filtered_buffer; }
    
    /**
     * @brief Obtenir le signal brut actuel
     */
    float* getRawSignal() { return eeg_buffer.raw_buffer; }
    
private:
    // Composants
    HighPassFilter hpf;
    LowPassFilter lpf;
    EEGBuffer eeg_buffer;
    float normalized_features[NUM_FEATURES];
    
    // Méthodes de filtrage
    void initFilters();
    float applyHighPassFilter(float sample);
    float applyLowPassFilter(float sample);
    
    // Méthodes d'extraction de features
    void extractTimeFeatures(float* signal, int size, float* features, int offset);
    void extractFrequencyFeatures(float* signal, int size, float* features, int offset);
    void extractStatisticalFeatures(float* signal, int size, float* features, int offset);
    
    // Fonctions utilitaires statistiques
    float calculateMean(float* data, int size);
    float calculateMedian(float* data, int size);
    float calculateStd(float* data, int size, float mean);
    float calculateVariance(float* data, int size, float mean);
    float calculateMin(float* data, int size);
    float calculateMax(float* data, int size);
    float calculateRMS(float* data, int size);
    float calculateEnergy(float* data, int size);
    float calculateSkewness(float* data, int size, float mean, float std);
    float calculateKurtosis(float* data, int size, float mean, float std);
    int countZeroCrossings(float* data, int size);
    float calculateEntropy(float* data, int size);
    
    // Normalisation des features selon le scaler
    void normalizeFeatures();
};

#endif // BITALINO_EEG_PREPROCESSOR_H
