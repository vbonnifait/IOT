/**
 * @file main.cpp
 * @brief Système de détection de crises épileptiques avec BITalino EEG + ESP32
 * 
 * Architecture:
 * BITalino EEG (ADC) → ESP32 → Prétraitement → TFLite Micro → Détection
 * 
 * Performances:
 * - Accuracy: 99.46%
 * - Modèle: 20.46 KB (quantized INT8)
 * - Latence: < 100ms par fenêtre
 */

#include <Arduino.h>
#include "BITalinoEEG_Preprocessor.h"

// TensorFlow Lite Micro
#include <TensorFlowLite.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"

// Modèle et paramètres
#include "model_data.h"
#include "scaler_params.h"

// ============================================================================
// CONFIGURATION MATÉRIELLE
// ============================================================================

// Pin de lecture ADC pour BITalino EEG
#define EEG_ADC_PIN 36  // GPIO36 (VP) - ADC1_CH0

// Pin pour LED d'indication
#define LED_NORMAL_PIN 2     // LED verte (intégrée ESP32)
#define LED_SEIZURE_PIN 4    // LED rouge externe
#define BUZZER_PIN 5         // Buzzer d'alerte

// Pin pour bouton de réinitialisation
#define RESET_BUTTON_PIN 0   // GPIO0 (BOOT button)

// ============================================================================
// CONFIGURATION DU SYSTÈME
// ============================================================================

// Seuil de détection de crise (probabilité)
#define SEIZURE_THRESHOLD 0.70f

// Nombre de détections consécutives requises pour confirmer une crise
#define CONFIRMATION_COUNT 3

// Période d'acquisition (selon SAMPLE_RATE)
#define ACQUISITION_PERIOD_US (1000000 / SAMPLE_RATE)

// ============================================================================
// VARIABLES GLOBALES
// ============================================================================

// Préprocesseur EEG
BITalinoEEGPreprocessor eeg_preprocessor;

// TensorFlow Lite Micro
namespace {
    tflite::ErrorReporter* error_reporter = nullptr;
    const tflite::Model* model = nullptr;
    tflite::MicroInterpreter* interpreter = nullptr;
    TfLiteTensor* input_tensor = nullptr;
    TfLiteTensor* output_tensor = nullptr;
    
    // Tensor Arena (mémoire pour TFLite)
    constexpr int kTensorArenaSize = 30 * 1024;  // 30KB
    alignas(16) uint8_t tensor_arena[kTensorArenaSize];
}

// Statistiques
unsigned long total_inferences = 0;
unsigned long seizures_detected = 0;
unsigned int consecutive_detections = 0;
bool seizure_active = false;

// Timers
unsigned long last_acquisition_time = 0;
unsigned long last_stats_print = 0;

// ============================================================================
// DÉCLARATIONS DE FONCTIONS
// ============================================================================

void setupTensorFlowLite();
void setupHardware();
void acquireAndProcess();
float runInference(float* features);
void handleSeizureDetection(float probability);
void handleNormalState(float probability);
void printStatistics();
void triggerSeizureAlert();
void stopSeizureAlert();
void checkResetButton();

// ============================================================================
// SETUP
// ============================================================================

void setup() {
    Serial.begin(115200);
    while (!Serial && millis() < 5000); // Attendre le port série (max 5s)
    
    delay(500);
    
    Serial.println("\n\n");
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║                                                              ║");
    Serial.println("║     SYSTÈME DE DÉTECTION DE CRISES ÉPILEPTIQUES             ║");
    Serial.println("║          BITalino EEG + ESP32 + TinyML                      ║");
    Serial.println("║                                                              ║");
    Serial.println("╠══════════════════════════════════════════════════════════════╣");
    Serial.println("║  Modèle: TensorFlow Lite Micro (INT8 Quantized)             ║");
    Serial.println("║  Taille: 20.46 KB                                            ║");
    Serial.println("║  Accuracy: 99.46%                                            ║");
    Serial.println("║  Precision: 100.00% | Recall: 98.91%                         ║");
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    Serial.println();
    
    // 1. Configuration matérielle
    setupHardware();
    
    // 2. Initialisation du préprocesseur
    eeg_preprocessor.begin();
    Serial.println();
    
    // 3. Initialisation TensorFlow Lite
    setupTensorFlowLite();
    Serial.println();
    
    // 4. Test de lecture ADC
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║  Test de lecture ADC BITalino...                             ║");
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    
    for (int i = 0; i < 5; i++) {
        int adc_value = analogRead(EEG_ADC_PIN);
        float microvolts = eeg_preprocessor.convertADCtoMicrovolts(adc_value);
        Serial.printf("  Test %d: ADC = %4d → EEG = %+8.2f µV\n", i+1, adc_value, microvolts);
        delay(100);
    }
    
    Serial.println();
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║  SYSTÈME PRÊT - Début de la détection                       ║");
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    Serial.println();
    
    last_acquisition_time = micros();
    last_stats_print = millis();
}

// ============================================================================
// LOOP PRINCIPAL
// ============================================================================

void loop() {
    unsigned long current_time = micros();
    
    // Acquisition à la fréquence d'échantillonnage
    if (current_time - last_acquisition_time >= ACQUISITION_PERIOD_US) {
        last_acquisition_time = current_time;
        acquireAndProcess();
    }
    
    // Afficher les statistiques toutes les 10 secondes
    if (millis() - last_stats_print >= 10000) {
        printStatistics();
        last_stats_print = millis();
    }
    
    // Vérifier le bouton de réinitialisation
    checkResetButton();
    
    // Petit délai pour éviter de saturer le CPU
    delayMicroseconds(100);
}

// ============================================================================
// CONFIGURATION MATÉRIELLE
// ============================================================================

void setupHardware() {
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║  Configuration matérielle...                                 ║");
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    
    // Configuration ADC
    analogReadResolution(10);  // 10-bit pour BITalino
    analogSetAttenuation(ADC_11db);  // 0-3.3V
    
    // Configuration des pins
    pinMode(LED_NORMAL_PIN, OUTPUT);
    pinMode(LED_SEIZURE_PIN, OUTPUT);
    pinMode(BUZZER_PIN, OUTPUT);
    pinMode(RESET_BUTTON_PIN, INPUT_PULLUP);
    
    // État initial
    digitalWrite(LED_NORMAL_PIN, HIGH);
    digitalWrite(LED_SEIZURE_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
    
    Serial.printf("  ✓ ADC configuré (Pin %d)\n", EEG_ADC_PIN);
    Serial.printf("  ✓ LED Normale (Pin %d)\n", LED_NORMAL_PIN);
    Serial.printf("  ✓ LED Crise (Pin %d)\n", LED_SEIZURE_PIN);
    Serial.printf("  ✓ Buzzer (Pin %d)\n", BUZZER_PIN);
    Serial.println("  ✓ Configuration matérielle terminée");
}

// ============================================================================
// CONFIGURATION TENSORFLOW LITE
// ============================================================================

void setupTensorFlowLite() {
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║  Initialisation TensorFlow Lite Micro...                    ║");
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    
    // Error reporter
    static tflite::MicroErrorReporter micro_error_reporter;
    error_reporter = &micro_error_reporter;
    
    // Charger le modèle
    model = tflite::GetModel(model_data);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        Serial.printf("  ❌ Version du schéma incompatible: %d vs %d\n",
                     model->version(), TFLITE_SCHEMA_VERSION);
        while (1);
    }
    Serial.printf("  ✓ Modèle chargé (%u bytes)\n", model_data_len);
    
    // Créer l'interpréteur
    static tflite::AllOpsResolver resolver;
    static tflite::MicroInterpreter static_interpreter(
        model, resolver, tensor_arena, kTensorArenaSize, error_reporter);
    interpreter = &static_interpreter;
    
    // Allouer les tensors
    TfLiteStatus allocate_status = interpreter->AllocateTensors();
    if (allocate_status != kTfLiteOk) {
        Serial.println("  ❌ Erreur d'allocation des tensors!");
        while (1);
    }
    Serial.printf("  ✓ Tensors alloués (Arena: %d KB)\n", kTensorArenaSize / 1024);
    
    // Obtenir les pointeurs vers les tensors d'entrée/sortie
    input_tensor = interpreter->input(0);
    output_tensor = interpreter->output(0);
    
    // Afficher les détails
    Serial.printf("  ✓ Input tensor: [%d features]\n", input_tensor->dims->data[1]);
    Serial.printf("  ✓ Output tensor: [%d classes]\n", output_tensor->dims->data[1]);
    Serial.println("  ✓ TensorFlow Lite Micro initialisé");
}

// ============================================================================
// ACQUISITION ET TRAITEMENT
// ============================================================================

void acquireAndProcess() {
    // 1. Lire l'ADC BITalino
    int adc_value = analogRead(EEG_ADC_PIN);
    
    // 2. Ajouter au buffer et prétraiter
    bool window_ready = eeg_preprocessor.addSample(adc_value);
    
    // 3. Si une fenêtre est complète, faire l'inférence
    if (window_ready) {
        // Extraire et normaliser les features
        float* features = eeg_preprocessor.getNormalizedFeatures();
        
        if (features != nullptr) {
            // Faire l'inférence
            float seizure_probability = runInference(features);
            
            // Gérer la détection
            if (seizure_probability > SEIZURE_THRESHOLD) {
                handleSeizureDetection(seizure_probability);
            } else {
                handleNormalState(seizure_probability);
            }
            
            total_inferences++;
        }
    }
}

// ============================================================================
// INFÉRENCE TENSORFLOW LITE
// ============================================================================

float runInference(float* features) {
    // Copier les features dans le tensor d'input
    for (int i = 0; i < NUM_FEATURES; i++) {
        input_tensor->data.f[i] = features[i];
    }
    
    // Faire l'inférence
    unsigned long inference_start = micros();
    TfLiteStatus invoke_status = interpreter->Invoke();
    unsigned long inference_time = micros() - inference_start;
    
    if (invoke_status != kTfLiteOk) {
        Serial.println("❌ Erreur d'inférence!");
        return 0.0f;
    }
    
    // Lire la probabilité de crise
    float seizure_probability = output_tensor->data.f[0];
    
    // Debug (afficher de temps en temps)
    if (total_inferences % 50 == 0) {
        Serial.printf("⚡ Inférence #%lu: P(crise)=%.1f%% (latence: %lu µs)\n",
                     total_inferences, seizure_probability * 100, inference_time);
    }
    
    return seizure_probability;
}

// ============================================================================
// GESTION DES DÉTECTIONS
// ============================================================================

void handleSeizureDetection(float probability) {
    consecutive_detections++;
    
    // Confirmation: plusieurs détections consécutives
    if (consecutive_detections >= CONFIRMATION_COUNT && !seizure_active) {
        seizure_active = true;
        seizures_detected++;
        
        Serial.println();
        Serial.println("╔══════════════════════════════════════════════════════════════╗");
        Serial.println("║                                                              ║");
        Serial.println("║            ⚠️  ALERTE CRISE DÉTECTÉE ⚠️                      ║");
        Serial.println("║                                                              ║");
        Serial.println("╠══════════════════════════════════════════════════════════════╣");
        Serial.printf("║  Probabilité: %.1f%%                                        ║\n", 
                     probability * 100);
        Serial.printf("║  Détections consécutives: %u                                 ║\n",
                     consecutive_detections);
        Serial.printf("║  Total crises: %lu                                          ║\n",
                     seizures_detected);
        Serial.println("╚══════════════════════════════════════════════════════════════╝");
        Serial.println();
        
        triggerSeizureAlert();
    }
    else if (seizure_active) {
        // Crise toujours active
        if (consecutive_detections % 10 == 0) {
            Serial.printf("⚠️  Crise active (P=%.1f%%, durée: %u fenêtres)\n",
                         probability * 100, consecutive_detections);
        }
    }
}

void handleNormalState(float probability) {
    if (seizure_active) {
        // Fin de la crise
        seizure_active = false;
        
        Serial.println();
        Serial.println("╔══════════════════════════════════════════════════════════════╗");
        Serial.println("║  ✓ Retour à l'état normal                                    ║");
        Serial.println("╚══════════════════════════════════════════════════════════════╝");
        Serial.println();
        
        stopSeizureAlert();
    }
    
    consecutive_detections = 0;
    
    // Affichage périodique
    if (total_inferences % 100 == 0) {
        Serial.printf("✓ Normal (P(crise)=%.1f%%)\n", probability * 100);
    }
}

// ============================================================================
// SYSTÈME D'ALERTE
// ============================================================================

void triggerSeizureAlert() {
    // LED rouge clignotante
    digitalWrite(LED_NORMAL_PIN, LOW);
    digitalWrite(LED_SEIZURE_PIN, HIGH);
    
    // Buzzer (pattern d'alerte)
    for (int i = 0; i < 3; i++) {
        digitalWrite(BUZZER_PIN, HIGH);
        delay(200);
        digitalWrite(BUZZER_PIN, LOW);
        delay(100);
    }
    
    // TODO: Envoyer notification Bluetooth
    // TODO: Envoyer notification WiFi/Cloud
}

void stopSeizureAlert() {
    digitalWrite(LED_NORMAL_PIN, HIGH);
    digitalWrite(LED_SEIZURE_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
}

// ============================================================================
// STATISTIQUES
// ============================================================================

void printStatistics() {
    Serial.println();
    Serial.println("╔══════════════════════════════════════════════════════════════╗");
    Serial.println("║  STATISTIQUES                                                ║");
    Serial.println("╠══════════════════════════════════════════════════════════════╣");
    Serial.printf("║  Inférences totales: %lu                                    ║\n", 
                 total_inferences);
    Serial.printf("║  Crises détectées: %lu                                      ║\n",
                 seizures_detected);
    Serial.printf("║  État actuel: %s                                    ║\n",
                 seizure_active ? "⚠️  CRISE" : "✓ Normal");
    Serial.printf("║  Uptime: %lu secondes                                       ║\n",
                 millis() / 1000);
    Serial.printf("║  Mémoire libre: %u bytes                                    ║\n",
                 ESP.getFreeHeap());
    Serial.println("╚══════════════════════════════════════════════════════════════╝");
    Serial.println();
}

// ============================================================================
// BOUTON DE RÉINITIALISATION
// ============================================================================

void checkResetButton() {
    static unsigned long button_press_time = 0;
    static bool button_was_pressed = false;
    
    bool button_pressed = (digitalRead(RESET_BUTTON_PIN) == LOW);
    
    if (button_pressed && !button_was_pressed) {
        button_press_time = millis();
        button_was_pressed = true;
    }
    
    if (button_pressed && button_was_pressed) {
        if (millis() - button_press_time > 3000) {
            Serial.println("\n🔄 RÉINITIALISATION DU SYSTÈME...\n");
            
            eeg_preprocessor.reset();
            total_inferences = 0;
            seizures_detected = 0;
            consecutive_detections = 0;
            seizure_active = false;
            
            stopSeizureAlert();
            
            Serial.println("✓ Système réinitialisé\n");
            
            button_was_pressed = false;
        }
    }
    
    if (!button_pressed && button_was_pressed) {
        button_was_pressed = false;
    }
}
