/**
 * @file BITalinoEEG_Preprocessor.cpp
 * @brief Implémentation du prétraitement des signaux EEG BITalino
 */

#include "BITalinoEEG_Preprocessor.h"
#include "scaler_params.h"
#include <algorithm>

// ============================================================================
// COEFFICIENTS DES FILTRES BUTTERWORTH (calculés avec scipy.signal)
// ============================================================================

// Filtre passe-haut 0.5 Hz @ 178 Hz (Butterworth 4ème ordre)
const float HPF_B[5] = {0.9895f, -3.9580f, 5.9370f, -3.9580f, 0.9895f};
const float HPF_A[5] = {1.0000f, -3.9580f, 5.9162f, -3.9370f, 0.9790f};

// Filtre passe-bas 40 Hz @ 178 Hz (Butterworth 4ème ordre)  
const float LPF_B[5] = {0.0201f, 0.0804f, 0.1206f, 0.0804f, 0.0201f};
const float LPF_A[5] = {1.0000f, -1.9644f, 1.7469f, -0.7498f, 0.1327f};

// ============================================================================
// CONSTRUCTEUR
// ============================================================================

BITalinoEEGPreprocessor::BITalinoEEGPreprocessor() {
    eeg_buffer.buffer_index = 0;
    eeg_buffer.window_ready = false;
}

// ============================================================================
// INITIALISATION
// ============================================================================

void BITalinoEEGPreprocessor::begin() {
    initFilters();
    reset();
    
    Serial.println("╔════════════════════════════════════════════════════════════╗");
    Serial.println("║  Préprocesseur EEG BITalino initialisé                    ║");
    Serial.println("╠════════════════════════════════════════════════════════════╣");
    Serial.printf("║  Fréquence d'échantillonnage: %d Hz                      ║\n", SAMPLE_RATE);
    Serial.printf("║  Taille de fenêtre: %d échantillons (%.1f sec)          ║\n", 
                  WINDOW_SIZE, (float)WINDOW_SIZE/SAMPLE_RATE);
    Serial.printf("║  Overlap: %d%% (%d échantillons)                        ║\n", 
                  OVERLAP_PERCENTAGE, OVERLAP_SIZE);
    Serial.printf("║  Nombre de features: %d                                  ║\n", NUM_FEATURES);
    Serial.println("║  Filtres: Passe-bande 0.5-40 Hz (Butterworth 4ème)       ║");
    Serial.println("╚════════════════════════════════════════════════════════════╝");
}

void BITalinoEEGPreprocessor::initFilters() {
    // Initialiser les coefficients du filtre passe-haut
    for (int i = 0; i < 5; i++) {
        hpf.a[i] = HPF_A[i];
        hpf.b[i] = HPF_B[i];
        hpf.x[i] = 0.0f;
        hpf.y[i] = 0.0f;
    }
    
    // Initialiser les coefficients du filtre passe-bas
    for (int i = 0; i < 5; i++) {
        lpf.a[i] = LPF_A[i];
        lpf.b[i] = LPF_B[i];
        lpf.x[i] = 0.0f;
        lpf.y[i] = 0.0f;
    }
}

// ============================================================================
// CONVERSION ADC VERS MICROVOLTS
// ============================================================================

float BITalinoEEGPreprocessor::convertADCtoMicrovolts(int adc_value) {
    // BITalino EEG: ADC 10-bit (0-1023)
    // V = (ADC / 1024) * VCC
    // EEG_voltage = (V - VCC/2) / Gain * 1000000 (pour µV)
    
    float voltage = ((float)adc_value / BITALINO_ADC_RESOLUTION) * BITALINO_VCC;
    float eeg_voltage = (voltage - EEG_VCC_HALF) / EEG_GAIN;
    
    return eeg_voltage * 1000000.0f;  // Convertir en microvolts
}

// ============================================================================
// FILTRAGE
// ============================================================================

float BITalinoEEGPreprocessor::applyHighPassFilter(float sample) {
    // Décalage du buffer
    for (int i = 4; i > 0; i--) {
        hpf.x[i] = hpf.x[i-1];
        hpf.y[i] = hpf.y[i-1];
    }
    
    hpf.x[0] = sample;
    
    // Calcul de la sortie (équation aux différences)
    hpf.y[0] = hpf.b[0] * hpf.x[0];
    for (int i = 1; i < 5; i++) {
        hpf.y[0] += hpf.b[i] * hpf.x[i] - hpf.a[i] * hpf.y[i];
    }
    
    return hpf.y[0];
}

float BITalinoEEGPreprocessor::applyLowPassFilter(float sample) {
    // Décalage du buffer
    for (int i = 4; i > 0; i--) {
        lpf.x[i] = lpf.x[i-1];
        lpf.y[i] = lpf.y[i-1];
    }
    
    lpf.x[0] = sample;
    
    // Calcul de la sortie
    lpf.y[0] = lpf.b[0] * lpf.x[0];
    for (int i = 1; i < 5; i++) {
        lpf.y[0] += lpf.b[i] * lpf.x[i] - lpf.a[i] * lpf.y[i];
    }
    
    return lpf.y[0];
}

// ============================================================================
// AJOUT D'ÉCHANTILLON
// ============================================================================

bool BITalinoEEGPreprocessor::addSample(int adc_value) {
    // 1. Convertir ADC en microvolts
    float microvolts = convertADCtoMicrovolts(adc_value);
    
    // 2. Appliquer les filtres
    float hpf_output = applyHighPassFilter(microvolts);
    float filtered = applyLowPassFilter(hpf_output);
    
    // 3. Stocker dans le buffer circulaire
    eeg_buffer.raw_buffer[eeg_buffer.buffer_index] = microvolts;
    eeg_buffer.filtered_buffer[eeg_buffer.buffer_index] = filtered;
    
    eeg_buffer.buffer_index++;
    
    // 4. Vérifier si la fenêtre est complète
    if (eeg_buffer.buffer_index >= WINDOW_SIZE) {
        eeg_buffer.buffer_index = 0;
        eeg_buffer.window_ready = true;
        return true;  // Fenêtre prête pour l'inférence
    }
    
    return false;
}

// ============================================================================
// EXTRACTION DE FEATURES
// ============================================================================

float* BITalinoEEGPreprocessor::extractFeatures() {
    if (!eeg_buffer.window_ready) {
        Serial.println("⚠️  Fenêtre non complète, features non extraites");
        return nullptr;
    }
    
    int feature_idx = 0;
    
    // Travailler sur le signal filtré
    float* signal = eeg_buffer.filtered_buffer;
    
    // ---- FEATURES TEMPORELLES ----
    extractTimeFeatures(signal, WINDOW_SIZE, eeg_buffer.features, feature_idx);
    feature_idx += 16;  // 16 features temporelles
    
    // ---- FEATURES STATISTIQUES ----
    extractStatisticalFeatures(signal, WINDOW_SIZE, eeg_buffer.features, feature_idx);
    feature_idx += 10;  // 10 features statistiques
    
    // ---- FEATURES PAR SEGMENTS (pour capturer la dynamique temporelle) ----
    // Diviser le signal en segments et extraire des features par segment
    int num_segments = 7;
    int segment_size = WINDOW_SIZE / num_segments;
    
    for (int seg = 0; seg < num_segments; seg++) {
        int start_idx = seg * segment_size;
        extractTimeFeatures(&signal[start_idx], segment_size, 
                          eeg_buffer.features, feature_idx);
        feature_idx += 16;
        
        extractStatisticalFeatures(&signal[start_idx], segment_size,
                                 eeg_buffer.features, feature_idx);
        feature_idx += 10;
    }
    
    // Remplir les features restantes avec des statistiques globales
    while (feature_idx < NUM_FEATURES) {
        eeg_buffer.features[feature_idx++] = calculateMean(signal, WINDOW_SIZE);
    }
    
    return eeg_buffer.features;
}

void BITalinoEEGPreprocessor::extractTimeFeatures(float* signal, int size, 
                                                   float* features, int offset) {
    float mean = calculateMean(signal, size);
    float std = calculateStd(signal, size, mean);
    
    features[offset + 0] = mean;
    features[offset + 1] = calculateMedian(signal, size);
    features[offset + 2] = std;
    features[offset + 3] = calculateVariance(signal, size, mean);
    features[offset + 4] = calculateMin(signal, size);
    features[offset + 5] = calculateMax(signal, size);
    features[offset + 6] = features[offset + 5] - features[offset + 4]; // range
    features[offset + 7] = calculateRMS(signal, size);
    features[offset + 8] = calculateEnergy(signal, size);
    features[offset + 9] = calculateSkewness(signal, size, mean, std);
    features[offset + 10] = calculateKurtosis(signal, size, mean, std);
    features[offset + 11] = (float)countZeroCrossings(signal, size);
    features[offset + 12] = calculateEntropy(signal, size);
    
    // Différences moyennes et std
    float sum_diff = 0.0f;
    for (int i = 1; i < size; i++) {
        sum_diff += fabs(signal[i] - signal[i-1]);
    }
    features[offset + 13] = sum_diff / (size - 1);
    
    float mean_diff = features[offset + 13];
    float sum_sq_diff = 0.0f;
    for (int i = 1; i < size; i++) {
        float diff = fabs(signal[i] - signal[i-1]) - mean_diff;
        sum_sq_diff += diff * diff;
    }
    features[offset + 14] = sqrt(sum_sq_diff / (size - 1));
    
    // Peak-to-peak
    features[offset + 15] = features[offset + 5] - features[offset + 4];
}

void BITalinoEEGPreprocessor::extractStatisticalFeatures(float* signal, int size,
                                                         float* features, int offset) {
    float mean = calculateMean(signal, size);
    float std = calculateStd(signal, size, mean);
    
    features[offset + 0] = mean;
    features[offset + 1] = std;
    features[offset + 2] = calculateMin(signal, size);
    features[offset + 3] = calculateMax(signal, size);
    features[offset + 4] = calculateRMS(signal, size);
    features[offset + 5] = calculateEnergy(signal, size);
    features[offset + 6] = calculateSkewness(signal, size, mean, std);
    features[offset + 7] = calculateKurtosis(signal, size, mean, std);
    features[offset + 8] = (float)countZeroCrossings(signal, size);
    features[offset + 9] = calculateEntropy(signal, size);
}

// ============================================================================
// NORMALISATION DES FEATURES
// ============================================================================

float* BITalinoEEGPreprocessor::getNormalizedFeatures() {
    if (!eeg_buffer.window_ready) {
        return nullptr;
    }
    
    // Extraire d'abord les features si ce n'est pas déjà fait
    if (eeg_buffer.features[0] == 0.0f) {
        extractFeatures();
    }
    
    normalizeFeatures();
    return normalized_features;
}

void BITalinoEEGPreprocessor::normalizeFeatures() {
    // Appliquer la standardisation: z = (x - mean) / std
    for (int i = 0; i < NUM_FEATURES; i++) {
        normalized_features[i] = (eeg_buffer.features[i] - scaler_mean[i]) / scaler_scale[i];
    }
}

// ============================================================================
// FONCTIONS STATISTIQUES
// ============================================================================

float BITalinoEEGPreprocessor::calculateMean(float* data, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += data[i];
    }
    return sum / size;
}

float BITalinoEEGPreprocessor::calculateMedian(float* data, int size) {
    float temp[size];
    memcpy(temp, data, size * sizeof(float));
    std::sort(temp, temp + size);
    
    if (size % 2 == 0) {
        return (temp[size/2 - 1] + temp[size/2]) / 2.0f;
    } else {
        return temp[size/2];
    }
}

float BITalinoEEGPreprocessor::calculateStd(float* data, int size, float mean) {
    return sqrt(calculateVariance(data, size, mean));
}

float BITalinoEEGPreprocessor::calculateVariance(float* data, int size, float mean) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        float diff = data[i] - mean;
        sum += diff * diff;
    }
    return sum / size;
}

float BITalinoEEGPreprocessor::calculateMin(float* data, int size) {
    float min_val = data[0];
    for (int i = 1; i < size; i++) {
        if (data[i] < min_val) {
            min_val = data[i];
        }
    }
    return min_val;
}

float BITalinoEEGPreprocessor::calculateMax(float* data, int size) {
    float max_val = data[0];
    for (int i = 1; i < size; i++) {
        if (data[i] > max_val) {
            max_val = data[i];
        }
    }
    return max_val;
}

float BITalinoEEGPreprocessor::calculateRMS(float* data, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += data[i] * data[i];
    }
    return sqrt(sum / size);
}

float BITalinoEEGPreprocessor::calculateEnergy(float* data, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += data[i] * data[i];
    }
    return sum;
}

float BITalinoEEGPreprocessor::calculateSkewness(float* data, int size, 
                                                  float mean, float std) {
    if (std == 0.0f) return 0.0f;
    
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        float z = (data[i] - mean) / std;
        sum += z * z * z;
    }
    return sum / size;
}

float BITalinoEEGPreprocessor::calculateKurtosis(float* data, int size,
                                                  float mean, float std) {
    if (std == 0.0f) return 0.0f;
    
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        float z = (data[i] - mean) / std;
        sum += z * z * z * z;
    }
    return (sum / size) - 3.0f;  // Excess kurtosis
}

int BITalinoEEGPreprocessor::countZeroCrossings(float* data, int size) {
    int count = 0;
    for (int i = 1; i < size; i++) {
        if ((data[i-1] >= 0 && data[i] < 0) || (data[i-1] < 0 && data[i] >= 0)) {
            count++;
        }
    }
    return count;
}

float BITalinoEEGPreprocessor::calculateEntropy(float* data, int size) {
    // Shannon entropy simplifiée
    const int num_bins = 20;
    int histogram[num_bins] = {0};
    
    float min_val = calculateMin(data, size);
    float max_val = calculateMax(data, size);
    float range = max_val - min_val;
    
    if (range == 0.0f) return 0.0f;
    
    // Créer l'histogramme
    for (int i = 0; i < size; i++) {
        int bin = (int)((data[i] - min_val) / range * (num_bins - 1));
        bin = constrain(bin, 0, num_bins - 1);
        histogram[bin]++;
    }
    
    // Calculer l'entropie
    float entropy = 0.0f;
    for (int i = 0; i < num_bins; i++) {
        if (histogram[i] > 0) {
            float p = (float)histogram[i] / size;
            entropy -= p * log(p);
        }
    }
    
    return entropy;
}

// ============================================================================
// RÉINITIALISATION
// ============================================================================

void BITalinoEEGPreprocessor::reset() {
    eeg_buffer.buffer_index = 0;
    eeg_buffer.window_ready = false;
    
    memset(eeg_buffer.raw_buffer, 0, sizeof(eeg_buffer.raw_buffer));
    memset(eeg_buffer.filtered_buffer, 0, sizeof(eeg_buffer.filtered_buffer));
    memset(eeg_buffer.features, 0, sizeof(eeg_buffer.features));
    memset(normalized_features, 0, sizeof(normalized_features));
    
    // Réinitialiser les buffers des filtres
    memset(hpf.x, 0, sizeof(hpf.x));
    memset(hpf.y, 0, sizeof(hpf.y));
    memset(lpf.x, 0, sizeof(lpf.x));
    memset(lpf.y, 0, sizeof(lpf.y));
}
